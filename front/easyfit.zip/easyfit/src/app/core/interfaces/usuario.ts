export interface Usuario {

    email: string
    password: string
    nombre: string
    edad: number
    sexo: string
    altura: number
}
