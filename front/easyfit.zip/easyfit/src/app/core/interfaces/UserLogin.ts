import { Objetivo } from "./objetivo";
import { Usuario } from "./usuario";

export interface UserLogin {

    email: string
    password: string
    token: string
}
