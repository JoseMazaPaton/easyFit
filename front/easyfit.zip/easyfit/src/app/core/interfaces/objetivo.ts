export interface Objetivo {
    
    pesoActual: number
    pesoObjetivo: number
    objetivoUsuario: string
    opcionPeso: string
    actividad: string
}
