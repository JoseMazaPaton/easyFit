export interface Login {

    email: string,
    nombre: string,
    tipoRol?: string,
    token?: string
}
