import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-footer-landing',
  imports: [],
  templateUrl: './footer-landing.component.html',
  styleUrl: './footer-landing.component.css',
})
export class FooterLandingComponent {}
