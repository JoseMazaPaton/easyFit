import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-nav-bar-landing',
  imports: [],
  templateUrl: './nav-bar-landing.component.html',
  styleUrl: './nav-bar-landing.component.css',
})
export class NavBarLandingComponent {}
